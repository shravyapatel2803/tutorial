#include<stdio.h>
void main()
{
    char x;
    printf("PLeasse enter the chartar\n");
    scanf("%c",&x);
    printf("the ascii code of the char is %d",x);
}