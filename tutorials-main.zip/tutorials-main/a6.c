#include<stdio.h>
void main()
{
int b,a;
b=20;

a=10;
b=b-a;
a=b+a;
printf("a = %d",a);
printf("b = %d",b);
}