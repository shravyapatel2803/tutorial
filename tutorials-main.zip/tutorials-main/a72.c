#include <stdio.h>
int main()
{
    int arr[10],n,temp1,temp2;
    printf("please enter the no. of rotation\n");
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        
        for(int j=0;j<=i;j++)
        {

        }
    }
}