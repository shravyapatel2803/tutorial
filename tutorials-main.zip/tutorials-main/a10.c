# include <stdio.h>
void main()
{
    int m,p,c,e;
    m=200;
    p=200;
    c=200;
    e=100;
    int cutoff= (m/2)+(p/2)+(c/2)+e;
    printf("cutoff mark is %d\n",cutoff);

}