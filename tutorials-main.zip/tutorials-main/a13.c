# include <stdio.h>
int main()
{
int a;
printf("PLease enter the no\n");
scanf("%d",&a);
if (a%2==0){
    printf("the no is even\n");
}
   else{
    printf("the no is odd\n");
   }
    return 0;
}
