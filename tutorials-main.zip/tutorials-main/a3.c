# include <stdio.h>
void main(){
    int x;
    printf("Please enter the montly salary\n");
    scanf("%d",&x);
    x=x*12;
    printf("Your salary is %d\n",x);
}