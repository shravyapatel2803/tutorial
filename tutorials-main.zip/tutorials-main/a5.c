#include<stdio.h>
void main()
{
int a,b,temp;
a=10;
b=20;
temp=b;
a=temp;
printf("%d",a);
}
